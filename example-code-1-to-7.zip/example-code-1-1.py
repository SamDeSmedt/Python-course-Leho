#!/usr/bin/python3
import sys
print("Hello, I'm Fedora.")
print("You're using Python " + sys.version + ".")
# Ask for input and print
name = input("What is your name? ")
print("Hello, " + name + "!")